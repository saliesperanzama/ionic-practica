import { Component } from '@angular/core';
import { Product } from '../models/product.model';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

export class Tab1Page {
  public products: Product[] = [];
  constructor() {
    this.products.push({
      name: "Coca Cola",
      photo: "https://picsum.photos/500/300?random=",
      price: 20,
      type: "Abarrotes",
      description: "Coca Cola de vidrio, 500ml."
    });

    this.products.push({
      name: "Manzana",
      photo: "https://picsum.photos/500/300?random=",
      price: 50,
      type: "Frutas y Verduras",
      description: "1 kg de manzanas."
    });

    this.products.push({
      name: "Tylenol",
      photo: "https://picsum.photos/500/300?random=",
      price: 15,
      type: "Farmacia",
      description: "Paracetamol de 500g, 10 tabs."
    });

    this.products.push({
      name: "Fabuloso",
      photo: "https://picsum.photos/500/300?random=",
      price: 30,
      type: "Limpieza",
      description: "Fabuloso 1L olor frutal."
    });
  }
}