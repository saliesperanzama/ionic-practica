export interface Product{
    name: string;
    price: number;
    description?: string;
    type: string;
    photo: string;
}